I declare that this material, which I now submit for assessment, is entirely my
own work and has not been taken from the work of others, save and to the extent that such
work has been cited and acknowledged within the text of my work.

Sean Healy
13411482
